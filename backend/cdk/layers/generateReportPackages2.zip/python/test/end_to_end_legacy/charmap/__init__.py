"""This package contains the Character Map Test

from commit 2eab310cfd866ce24947c3a9d850ebda7c6d515d in 1.7.2 version:
github.com/reingart/pyfpdf/commit/2eab310cfd866ce24947c3a9d850ebda7c6d515d
"""
