"""This package contains image tests"""
