from matplotlib._docstring import *  # noqa: F401, F403
from matplotlib import _api
_api.warn_deprecated(
    "3.6", obj_type='module', name=f"{__name__}")
