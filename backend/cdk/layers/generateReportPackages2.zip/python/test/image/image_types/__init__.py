"""This package contains basic insertion of images tests"""
