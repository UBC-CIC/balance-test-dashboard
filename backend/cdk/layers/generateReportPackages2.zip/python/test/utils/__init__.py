"""This package tests auxiliary and utility funtions"""
